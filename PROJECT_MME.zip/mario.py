import sys
from pygame import *
import os
import pygame
import pyganim
import random
import pygame_menu

#####
ICON_DIR = os.path.dirname(__file__)
full = os.path.join('other', 'heart.png')
live = pygame.image.load(full)
full1 = os.path.join('other', 'bul3.png')
bul = pygame.image.load(full1)
bul = pygame.transform.scale(bul, (30, 10))
#####

WIN_WIDTH = 800  # Ширина создаваемого окна
WIN_HEIGHT = 640  # Высота
DISPLAY = (WIN_WIDTH, WIN_HEIGHT)  # Группируем ширину и высоту в одну переменную
BACKGROUND_COLOR = "#161a1e"

pygame.init()
FPS = 50
clock = pygame.time.Clock()
screen = pygame.display.set_mode(DISPLAY)
fl = True
YELLOW = (255, 255, 0)


def terminate():
    pygame.quit()
    sys.exit()


def start_screen():
    pygame.display.set_icon(pygame.image.load("icon.jpg"))
    fon = pygame.transform.scale(load_image('post.jpg'), (WIN_WIDTH, WIN_HEIGHT))
    screen.blit(fon, (0, 0))

    pygame.mixer.music.load('mix_3m06s (audio-joiner.com).mp3')
    pygame.mixer.music.play()

    while True:
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                terminate()
            elif event.type == pygame.KEYDOWN or \
                    event.type == pygame.MOUSEBUTTONDOWN:
                return

        for i in pygame.event.get():
            if i.type == pygame.QUIT:
                sys.exit()

            elif i.type == pygame.KEYUP:
                if i.key == pygame.K_1:
                    pygame.mixer.music.pause()
                    # pygame.mixer.music.stop()
                elif i.key == pygame.K_2:
                    pygame.mixer.music.unpause()
                    # pygame.mixer.music.play()
                    pygame.mixer.music.set_volume(0.5)
                elif i.key == pygame.K_3:
                    pygame.mixer.music.unpause()
                    # pygame.mixer.music.play()
                    pygame.mixer.music.set_volume(1)

        pygame.time.delay(20)
        pygame.display.flip()
        clock.tick(FPS)


def set_difficulty(value, difficulty):
    global fl

    if difficulty == 1:
        fl = True
        pygame.mixer.music.unpause()
    if difficulty == 2:
        fl = False
        pygame.mixer.music.pause()


def menu():
    pygame.display.set_icon(pygame.image.load("icon.jpg"))
    menu = pygame_menu.Menu(640, 800, 'Welcome',
                            theme=pygame_menu.themes.THEME_DARK)
    menu.add_text_input('Name :', default='John Doe')
    menu.add_selector('Sound :', [('Yes', 1), ('No', 2)], onchange=set_difficulty)
    menu.add_button('Quit', pygame_menu.events.EXIT)
    menu.add_button('Play', main)
    menu.add_button('The authors', author)
    menu.mainloop(screen)
    if fl:
        pygame.mixer.music.load('mix_3m06s (audio-joiner.com).mp3')
        pygame.mixer.music.play()


def load_image(name, colorkey=None):
    fullname = os.path.join('enemy1', name)
    if not os.path.isfile(fullname):
        print(f"Файл с изображением '{fullname}' не найден")
        sys.exit()
    image = pygame.image.load(fullname)
    if colorkey is not None:
        image = image.convert()
        if colorkey == -1:
            colorkey = image.get_at((0, 0))
        image.set_colorkey(colorkey)
    else:
        image = image.convert_alpha()
    return image


def draw_lives(surf, lives):
    show = 0
    x = 650
    while show != lives:
        surf.blit(live, (x, 40))
        x += 50
        show += 1


# Объявляем переменные


PLATFORM_WIDTH = 32
PLATFORM_HEIGHT = 32
PLATFORM_COLOR = "#FF6262"
# Полный путь к каталогу с файлами

MOVE_SPEED = 7
WIDTH = 22
HEIGHT = 32
WIDTH_BUL = 150
HEIGHT_BUL = 75
COLOR = "#888888"
JUMP_POWER = 10
GRAVITY = 0.35  # Сила, которая будет тянуть нас вниз
ANIMATION_DELAY = 0.1  # скорость смены кадров

ANIMATION_RIGHT = [('%s/mario/r1.png' % ICON_DIR),
                   ('%s/mario/r2.png' % ICON_DIR),
                   ('%s/mario/r3.png' % ICON_DIR),
                   ('%s/mario/r4.png' % ICON_DIR),
                   ('%s/mario/r5.png' % ICON_DIR)]
ANIMATION_LEFT = [('%s/mario/l1.png' % ICON_DIR),
                  ('%s/mario/l2.png' % ICON_DIR),
                  ('%s/mario/l3.png' % ICON_DIR),
                  ('%s/mario/l4.png' % ICON_DIR),
                  ('%s/mario/l5.png' % ICON_DIR)]
ANIMATION_JUMP_LEFT = [('%s/mario/jl.png' % ICON_DIR, 0.1)]
ANIMATION_JUMP_RIGHT = [('%s/mario/jr.png' % ICON_DIR, 0.1)]
ANIMATION_JUMP = [('%s/mario/j.png' % ICON_DIR, 0.1)]
ANIMATION_STAY = [('%s/mario/0.png' % ICON_DIR, 0.1)]
ANIMATION_BULLET = [('%s/other/bul1.png' % ICON_DIR),
                    ('%s/other/bul2.png' % ICON_DIR),
                    ('%s/other/bul3.png' % ICON_DIR),
                    ('%s/other/bul4.png' % ICON_DIR)]

MONSTER_WIDTH = 32
MONSTER_HEIGHT = 47
MONSTER_COLOR = "#888888"

ANIMATION_DELAY2 = 0.5
MONSTER_WIDTH2 = 40
MONSTER_HEIGHT2 = 45
MONSTER_COLOR2 = "#888888"

ANIMATION_MONSTERHORYSONTAL_RIGHT = [('%s/enemy1/r1.png' % ICON_DIR),
                                     ('%s/enemy1/r2.png' % ICON_DIR),
                                     ('%s/enemy1/r3.png' % ICON_DIR)]

ANIMATION_MONSTERHORYSONTAL_LEFT = [('%s/enemy1/l1.png' % ICON_DIR),
                                    ('%s/enemy1/l2.png' % ICON_DIR),
                                    ('%s/enemy1/l3.png' % ICON_DIR)]

ANIMATION_MONSTERSTATIC = [('%s/enemy1/plant1.png' % ICON_DIR),
                           ('%s/enemy1/plant4.png' % ICON_DIR),
                           ('%s/enemy1/plant3.png' % ICON_DIR),
                           ('%s/enemy1/plant4.png' % ICON_DIR),
                           ('%s/enemy1/plant2.png' % ICON_DIR),
                           ('%s/enemy1/plant4.png' % ICON_DIR),
                           ('%s/enemy1/plant3.png' % ICON_DIR),
                           ('%s/enemy1/plant4.png' % ICON_DIR)]


class Player(sprite.Sprite):
    global entities, attacks

    def __init__(self, x, y):
        sprite.Sprite.__init__(self)
        ######
        self.lives = 3

        ######
        self.xvel = 0  # скорость перемещения. 0 - стоять на месте
        self.startX = x  # Начальная позиция Х, пригодится когда будем переигрывать уровень
        self.startY = y
        self.yvel = 0  # скорость вертикального перемещения
        self.onGround = False  # На земле ли я?
        self.image = Surface((WIDTH, HEIGHT))
        self.image.fill(Color(COLOR))
        self.rect = Rect(x, y, WIDTH, HEIGHT)

        # прямоугольный объект
        self.image.set_colorkey(Color(COLOR))  # делаем фон прозрачным
        #        Анимация движения вправо
        boltAnim = []
        for anim in ANIMATION_RIGHT:
            boltAnim.append((anim, ANIMATION_DELAY))
        self.boltAnimRight = pyganim.PygAnimation(boltAnim)
        self.boltAnimRight.play()
        #        Анимация движения влево
        boltAnim = []
        for anim in ANIMATION_LEFT:
            boltAnim.append((anim, ANIMATION_DELAY))
        self.boltAnimLeft = pyganim.PygAnimation(boltAnim)
        self.boltAnimLeft.play()
        # Анимация смерти
        boltAnim = []

        self.boltAnimStay = pyganim.PygAnimation(ANIMATION_STAY)
        self.boltAnimStay.play()
        self.boltAnimStay.blit(self.image, (0, 0))  # По-умолчанию, стоим

        self.boltAnimJumpLeft = pyganim.PygAnimation(ANIMATION_JUMP_LEFT)
        self.boltAnimJumpLeft.play()

        self.boltAnimJumpRight = pyganim.PygAnimation(ANIMATION_JUMP_RIGHT)
        self.boltAnimJumpRight.play()

        self.boltAnimJump = pyganim.PygAnimation(ANIMATION_JUMP)
        self.boltAnimJump.play()

    def update(self, left, right, up, platforms):

        if up:
            if self.onGround:  # прыгаем, только когда можем оттолкнуться от земли
                self.yvel = -JUMP_POWER
            if fl:
                pygame.mixer.Channel(1).play(pygame.mixer.Sound('sfx-13.mp3'))
            self.image.fill(Color(COLOR))
            self.boltAnimJump.blit(self.image, (0, 0))

        if left:
            self.xvel = -MOVE_SPEED  # Лево = x- n
            self.image.fill(Color(COLOR))
            if fl:
                pygame.mixer.Channel(1).play(pygame.mixer.Sound('sfx-4.mp3'))
            if up:  # для прыжка влево есть отдельная анимация
                self.boltAnimJumpLeft.blit(self.image, (0, 0))
            else:
                self.boltAnimLeft.blit(self.image, (0, 0))

        if right:
            self.xvel = MOVE_SPEED  # Право = x + n
            self.image.fill(Color(COLOR))
            if fl:
                pygame.mixer.Channel(1).play(pygame.mixer.Sound('sfx-4.mp3'))
            if up:
                self.boltAnimJumpRight.blit(self.image, (0, 0))
            else:
                self.boltAnimRight.blit(self.image, (0, 0))

        if not (left or right):  # стоим, когда нет указаний идти
            self.xvel = 0
            if not up:
                self.image.fill(Color(COLOR))
                self.boltAnimStay.blit(self.image, (0, 0))

        if not self.onGround:
            self.yvel += GRAVITY

        self.onGround = False;  # Мы не знаем, когда мы на земле((
        self.rect.y += self.yvel
        self.collide(0, self.yvel, platforms)

        self.rect.x += self.xvel  # переносим свои положение на xvel
        self.collide(self.xvel, 0, platforms)

    def collide(self, xvel, yvel, platforms):
        for el in platforms:
            if sprite.collide_rect(self, el):  # если есть пересечение платформы с игроком

                if xvel > 0:  # если движется вправо
                    self.rect.right = el.rect.left  # то не движется вправо

                if xvel < 0:  # если движется влево
                    self.rect.left = el.rect.right  # то не движется влево

                if yvel > 0:  # если падает вниз
                    self.rect.bottom = el.rect.top  # то не падает вниз
                    self.onGround = True  # и становится на что-то твердое
                    self.yvel = 0  # и энергия падения пропадает

                if yvel < 0:  # если движется вверх
                    self.rect.top = el.rect.bottom  # то не движется вверх
                    self.yvel = 0  # и энергия прыжка пропадает
                if isinstance(el, MovingEnemy):
                    self.lives -= 1
                    self.die()
                if isinstance(el, StaticEnemy):
                    self.lives -= 1
                    self.die()

    def die(self):

        time.wait(500)
        # перемещаемся в начальные координаты
        self.teleporting(self.startX, self.startY)

    def teleporting(self, goX, goY):
        self.rect.x = goX
        self.rect.y = goY


class MovingEnemy(sprite.Sprite):
    def __init__(self, x, y, left, up, maxLengthLeft, maxLengthRight):
        sprite.Sprite.__init__(self)
        self.image = Surface((MONSTER_WIDTH, MONSTER_HEIGHT))
        self.image.fill(Color(MONSTER_COLOR))
        self.rect = Rect(x, y, MONSTER_WIDTH, MONSTER_HEIGHT)
        self.image.set_colorkey(Color(MONSTER_COLOR))
        self.startX = x  # начальные координаты
        self.startY = y
        self.maxLengthLeft = maxLengthLeft  # максимальное расстояние, которое может пройти в одну сторону
        self.maxLengthRight = maxLengthRight  # максимальное расстояние, которое может пройти в одну сторону, вертикаль
        self.xvel = left  # cкорость передвижения по горизонтали, 0 - стоит на месте
        self.yvel = up  # скорость движения по вертикали, 0 - не двигается
        self.time = None
        boltAnim = []
        for anim in ANIMATION_MONSTERHORYSONTAL_LEFT:
            boltAnim.append((anim, ANIMATION_DELAY))
        self.boltAnimLeft = pyganim.PygAnimation(boltAnim)
        self.boltAnimLeft.play()

        boltAnim = []
        for anim in ANIMATION_MONSTERHORYSONTAL_RIGHT:
            boltAnim.append((anim, ANIMATION_DELAY))
        self.boltAnimRight = pyganim.PygAnimation(boltAnim)
        self.boltAnimRight.play()
        self.move = 1

    def update(self, platforms):  # по принципу героя
        if self.move == 1:
            self.image.fill(Color(MONSTER_COLOR))
            self.boltAnimRight.blit(self.image, (0, 0))
        else:
            self.image.fill(Color(MONSTER_COLOR))
            self.boltAnimLeft.blit(self.image, (0, 0))

        self.rect.y += self.yvel
        self.rect.x += self.xvel

        self.collide(platforms)

        if abs(self.startX - self.rect.x) > self.maxLengthLeft:
            self.xvel = -self.xvel
            if self.move == 1:
                self.move = 0
            else:
                self.move = 1
            # если прошли максимальное растояние, то идеи в обратную сторону
        if abs(self.startY - self.rect.y) > self.maxLengthRight:
            self.yvel = -self.yvel
            # если прошли максимальное растояние, то идеи в обратную сторону, вертикаль

        if self.time is not None:  # If the timer has been started...
            # and 500 ms have elapsed, kill the sprite.
            if self.time >= 500:
                self.kill()

    def collide(self, platforms):
        for p in platforms:
            if sprite.collide_rect(self, p) and self != p:  # если с чем-то или кем-то столкнулись
                self.xvel = - self.xvel  # то поворачиваем в обратную сторону
                self.yvel = - self.yvel
                if self.move == 1:
                    self.move = 0
                else:
                    self.move = 1


class StaticEnemy(sprite.Sprite):
    def __init__(self, x, y):
        sprite.Sprite.__init__(self)
        self.image = Surface((MONSTER_WIDTH2, MONSTER_HEIGHT2))
        self.image.fill(Color(MONSTER_COLOR2))
        self.rect = Rect(x, y, MONSTER_WIDTH2, MONSTER_HEIGHT2)
        self.image.set_colorkey(Color(MONSTER_COLOR2))
        self.startX = x  # начальные координаты
        self.startY = y
        boltAnim = []
        for anim in ANIMATION_MONSTERSTATIC:
            boltAnim.append((anim, ANIMATION_DELAY2))
        self.boltAnimStatic = pyganim.PygAnimation(boltAnim)
        self.boltAnimStatic.play()

    def update(self, platforms):
        self.image.fill(Color(MONSTER_COLOR))
        self.boltAnimStatic.blit(self.image, (0, 0))


class Bullet:
    def __init__(self, x, y, radius, color, napr):
        self.x = x
        self.y = y
        self.r = radius
        self.c = color
        self.napr = napr
        self.speed = 10 * napr

    def move(self, win):
        if fl:
            pygame.mixer.Channel(1).play(pygame.mixer.Sound('gun.mp3'))
        pygame.draw.circle(win, self.c, (self.x, self.y), self.r)


class Platform(sprite.Sprite):
    def __init__(self, x, y):
        sprite.Sprite.__init__(self)
        self.image = Surface((PLATFORM_WIDTH, PLATFORM_HEIGHT))
        self.image.fill(Color(PLATFORM_COLOR))
        self.image = image.load("%s/blocks/platform.png" % ICON_DIR)
        self.rect = Rect(x, y, PLATFORM_WIDTH, PLATFORM_HEIGHT)


class Camera(object):
    def __init__(self, camera_func, width, height):
        self.camera_func = camera_func
        self.state = Rect(0, 0, width, height)

    def apply(self, target):
        return target.rect.move(self.state.topleft)

    def update(self, target):
        self.state = self.camera_func(self.state, target.rect)


def camera_configure(camera, target_rect):
    l, t, _, _ = target_rect
    _, _, w, h = camera
    l, t = -l + WIN_WIDTH / 2, -t + WIN_HEIGHT / 2

    l = min(0, l)  # Не движемся дальше левой границы
    l = max(-(camera.width - WIN_WIDTH), l)  # Не движемся дальше правой границы
    t = max(-(camera.height - WIN_HEIGHT), t)  # Не движемся дальше нижней границы
    t = min(0, t)  # Не движемся дальше верхней границы

    return Rect(l, t, w, h)


def main():
    pygame.display.set_caption("MME-Mario Meat Eater")
    pygame.display.set_icon(pygame.image.load("icon.jpg"))
    bg = Surface((WIN_WIDTH, WIN_HEIGHT))  # Создание видимой поверхности
    monsters = pygame.sprite.Group()
    bg.fill(Color(BACKGROUND_COLOR))  # Заливаем поверхность сплошным цветом
    st_monsters = pygame.sprite.Group()
    hero_coords = Player(55, 55)  # создаем героя по (x,y) координатам
    left = right = False  # по умолчанию - стоим
    up = False
    lastNaprav = 'right'
    entities = pygame.sprite.Group()  # Все объекты
    platforms = []  # то, во что мы будем врезаться или опираться
    all_bullets = []
    entities.add(hero_coords)
    keys = pygame.key.get_pressed()
    level = [
        "----------------------------------",
        "-                                -",
        "-                                -",
        "-         *                      -",
        "-      --------                  -",
        "-                                -",
        "---                              -",
        "-                    *        ^  -",
        "-                   ----     --- -",
        "-                                -",
        "---                              -",
        "-                             *  -",
        "-                           ---- -",
        "-       ---                      -",
        "-                                -",
        "-                                -",
        "-           *                    -",
        "-   --------------------         -",
        "-                         ^      -",
        "-                         -      -",
        "-                            --  -",
        "-                                -",
        "-         ^                      -",
        "----------------------------------"]

    timer = pygame.time.Clock()
    x = y = 0  # координаты
    list_maxrange = [40, 50, 60]
    for row in level:  # вся строка
        for col in row:  # каждый символ
            if col == "-":
                pf = Platform(x, y)
                entities.add(pf)
                platforms.append(pf)
            if col == "*":
                mn = MovingEnemy(x, y - MONSTER_WIDTH // 2, 2, 0, random.choice(list_maxrange), 0)
                entities.add(mn)
                platforms.append(mn)
                monsters.add(mn)
            if col == "^":
                mn = StaticEnemy(x, y - MONSTER_WIDTH2 // 3)
                entities.add(mn)
                platforms.append(mn)
                st_monsters.add(mn)

            x += PLATFORM_WIDTH  # блоки платформы ставятся на ширине блоков
        y += PLATFORM_HEIGHT  # то же самое и с высотой
        x = 0  # на каждой новой строчке начинаем с нуля

    total_level_width = len(level[0]) * PLATFORM_WIDTH  # Высчитываем фактическую ширину уровня
    total_level_height = len(level) * PLATFORM_HEIGHT  # высоту

    camera = Camera(camera_configure, total_level_width, total_level_height)

    if fl:
        pygame.mixer.music.load('mix_4m20s (audio-joiner.com).mp3')
        pygame.mixer.music.play()

    while 1:  # Основной цикл программы
        timer.tick(60)

        for el in pygame.event.get():  # Обрабатываем события
            if el.type == QUIT:
                raise SystemExit("QUIT")
            elif el.type == pygame.MOUSEBUTTONDOWN:
                if fl:
                    pygame.mixer.music.load('mix_3m06s (audio-joiner.com).mp3')
                    pygame.mixer.music.play()
                return

            elif el.type == KEYDOWN and el.key == K_UP:
                up = True
            elif el.type == KEYDOWN and el.key == K_LEFT:
                left = True
                lastNaprav = 'left'
            elif el.type == KEYDOWN and el.key == K_RIGHT:
                right = True
                lastNaprav = 'right'
            elif el.type == KEYUP and el.key == K_UP:
                up = False
            elif el.type == KEYUP and el.key == K_RIGHT:
                right = False
                lastNaprav = 'right'
            elif el.type == KEYUP and el.key == K_LEFT:
                left = False
                lastNaprav = 'left'
        for bullet in all_bullets:
            if WIN_WIDTH > bullet.x > 0:
                bullet.x += bullet.speed
            else:
                all_bullets.pop(all_bullets.index(bullet))
        keys = pygame.key.get_pressed()
        if keys[pygame.K_m]:
            if lastNaprav == 'right':
                napr = 1
            else:
                napr = -1
            b = Bullet(hero_coords.rect.x, hero_coords.rect.y, 8, 'red', napr)
            all_bullets.append(b)
            b.move(screen)

        if hero_coords.lives == 0:
            if fl:
                pygame.mixer.music.load('mix_3m06s (audio-joiner.com).mp3')
                pygame.mixer.music.play()
            break
        screen.blit(bg, (0, 0))  # Перерисовка

        camera.update(hero_coords)  # центризируем камеру относительно персонажа
        hero_coords.update(left, right, up, platforms)  # передвижение
        monsters.update(platforms)
        st_monsters.update(platforms)
        draw_lives(screen, hero_coords.lives)
        # entities.draw(screen) # отображение
        for e in entities:
            screen.blit(e.image, camera.apply(e))

        pygame.display.update()  # обновление и вывод всех изменений на экран


def author():
    pygame.display.set_caption("MME-MARIO MEAT EATER")
    pygame.font.init()

    screen = pygame.display.set_mode(DISPLAY)
    screen.fill((153, 50, 204))

    f1 = pygame.font.Font(None, 36)
    text1 = f1.render('Лучшая', False,
                      (255, 255, 255))
    f2 = pygame.font.Font(None, 36)
    text2 = f2.render('Великолепная', False,
                      (255, 255, 255))
    f3 = pygame.font.Font(None, 36)
    text3 = f3.render('Гениальная', True,
                      (255, 255, 255))
    f4 = pygame.font.Font(None, 36)
    text4 = f4.render('@_chetnochek_', False,
                      (255, 255, 255))
    f5 = pygame.font.Font(None, 36)
    text5 = f5.render('@xenon_xenoff', False,
                      (255, 255, 255))
    f6 = pygame.font.Font(None, 36)
    text6 = f6.render('@surik_soya', True,
                      (255, 255, 255))
    f7 = pygame.font.Font(None, 50)
    text7 = f7.render('Мечтают о 100 баллах', True,
                      (255, 255, 255))

    clock = pygame.time.Clock()
    if fl == True:
        pygame.mixer.music.load('Markul-Худший друг-kissvk.com.mp3')
        pygame.mixer.music.play()

    my_image = pygame.image.load("anya.jpg").convert_alpha()
    scaled_image = pygame.transform.scale(my_image, (240, 350))

    my_image2 = pygame.image.load("ksenka.jpg").convert_alpha()
    scaled_image2 = pygame.transform.scale(my_image2, (240, 350))

    my_image3 = pygame.image.load("gelic.jpg").convert_alpha()
    scaled_image3 = pygame.transform.scale(my_image3, (240, 350))

    while True:
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                terminate()
            elif event.type == pygame.KEYDOWN or \
                    event.type == pygame.MOUSEBUTTONDOWN:
                if fl:
                    pygame.mixer.music.load('mix_3m06s (audio-joiner.com).mp3')
                    pygame.mixer.music.play()
                return

        for i in pygame.event.get():
            if i.type == pygame.QUIT:
                sys.exit()

        screen.fill((147, 112, 216))
        screen.blit(scaled_image, (25, 80))
        screen.blit(scaled_image2, (280, 80))
        screen.blit(scaled_image3, (535, 80))
        screen.blit(text1, (90, 450))
        screen.blit(text2, (310, 450))
        screen.blit(text3, (580, 450))
        screen.blit(text4, (40, 500))
        screen.blit(text5, (310, 500))
        screen.blit(text6, (580, 500))
        screen.blit(text7, (200, 30))
        pygame.display.update()

        pygame.display.flip()
        clock.tick(10)
    pygame.quit()


if __name__ == "__main__":
    start_screen()
    menu()
    main()